# Goji Foundation Design

Date: 2026-09-15
Target branch: `Goji-foundation`
Status: Approved design, pre-implementation

## Goal

Turn `Sleezy2345/shin-2.0` from a skeletal repository into the smallest useful, testable Goji codebase without duplicating the canonical intelligence already living in Supabase/GENOME.

GitHub will become Goji's runnable integration/application layer while Supabase remains the durable source of truth for GENOME state, frozen predictions, settlements, learning status, and canonical database behavior.

## Principles

1. Do not duplicate GENOME. GitHub code calls canonical Supabase functions rather than recreating database rules locally.
2. Preserve the Goji data flow and provenance needed for ECHOSENSE -> CARAPACE -> PLASMA -> SPINES.
3. Keep Goji probability separate from sportsbook/market implied probability.
4. Never commit secrets. API keys and Supabase credentials come from environment variables/GitHub secrets.
5. Any baseline output is explicitly labeled `COLD_START` and must not impersonate a trained REACTOR model.
6. Prefer `NO_ROAR`/blocked output to fabricated confidence when inputs are insufficient.
7. Keep the first publish small and testable.

## Initial Repository Shape

```text
.github/
  workflows/
    ci.yml
    sgo-connectivity.yml

go ji/                  # actual path: goji/
  __init__.py
  config.py
  sportsgameodds.py
  genome.py
  models.py
  baseline.py

scripts/
  goji_check.py

tests/
  test_config.py
  test_sportsgameodds.py
  test_genome.py
  test_baseline.py

requirements.txt
README.md
```

## Components

### `goji.config`
Loads runtime configuration from environment variables. Configuration is validated only for the capability being used so importing Goji does not fail because an unrelated integration is not configured.

### `goji.sportsgameodds`
Minimal SportsGameOdds client that authenticates from `SPORTSGAMEODDS_API_KEY`, requests events, uses timeouts and clear error handling, normalizes provider responses, and preserves provider IDs/timestamps/provenance. It replaces the workflow's current import of nonexistent `shin.sportsgameodds` code.

### `goji.genome`
Thin adapter over canonical Supabase/GENOME functions. First-slice operations:
- `genome_freeze_slate`
- `genome_review_queue`
- `genome_scoreboards`
- `genome_record_wager_link`

Settlement writes remain routed through the existing canonical GENOME settlement path, never direct table mutation.

### `goji.models`
Small typed/dataclass-style domain objects for normalized games, predictions, provenance, and cold-start output so provider payload shapes do not leak through decision code.

### `goji.baseline`
Simple cold-start baseline behind a replaceable interface. It always labels output `COLD_START`, uses only available pregame inputs, never turns sportsbook implied probability into Goji probability, and returns `NO_ROAR`/insufficient-data rather than forcing a prediction.

### `scripts/goji_check.py`
Small smoke-test CLI for local/CI use. It validates configuration and can query a few SportsGameOdds events when credentials are present. It is not intended to be the final Goji CLI.

## Data Flow

1. SportsGameOdds retrieves provider data.
2. Data is normalized into Goji domain records with provenance preserved.
3. Baseline/decision code may create explicitly cold-start prediction objects only when enough inputs exist.
4. Valid prediction batches are sent through canonical `genome_freeze_slate`.
5. Review/scoreboard reads come through canonical GENOME functions.
6. No local SQLite, duplicate memory database, or second settlement architecture is introduced.

## Error Handling

- Explicit network timeouts.
- Typed integration errors with provider/operation context but no secrets.
- Actionable missing-credential errors.
- Malformed upstream records are rejected or skipped explicitly rather than silently coerced.
- Supabase RPC errors preserve operation context.
- Secrets are never logged.

## GitHub Actions

### `ci.yml`
Runs on pushes and pull requests using Python 3.11. Installs dependencies, imports Goji, and runs the unit tests. Tests require no live credentials.

### `sgo-connectivity.yml`
Keep the existing manually triggered workflow, but update it to import `goji.sportsgameodds` and use the real checked-in package. This live connectivity check may require `SPORTSGAMEODDS_API_KEY`.

## Tests

Use mocked HTTP/Supabase boundaries. Minimum coverage:
- environment configuration validation;
- SportsGameOdds auth/request/normalization;
- provider error/timeout behavior;
- GENOME adapter RPC names/payloads;
- cold-start labeling;
- refusal to force a prediction when evidence is insufficient;
- no unit test requires live credentials.

## README

Replace the current Shin-only README with a concise Goji overview that explains:
- Goji is the current project name; Shin is historical lineage;
- current capabilities and limits;
- required environment variables;
- how to run tests/smoke checks;
- Supabase/GENOME is canonical durable state.

## Explicitly Out of Scope

- full trained REACTOR implementation;
- automated live-game monitoring;
- autonomous settlement scheduler;
- bankroll sizing engine;
- every Concept Lab subsystem as Python code;
- web UI;
- historical Supabase migration into GitHub;
- renaming the GitHub repository itself.

## Success Criteria

The foundation is merge-ready when:
1. `goji` imports cleanly on Python 3.11;
2. all unit tests pass without live secrets;
3. SportsGameOdds connectivity workflow points to real checked-in code;
4. GENOME access uses canonical function adapters rather than duplicate persistence;
5. no credentials are committed;
6. README accurately describes current capability/cold-start limits;
7. changes are reviewed from `Goji-foundation` before merging to `main`.
