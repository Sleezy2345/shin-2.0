# Goji Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn `Sleezy2345/shin-2.0` into the smallest runnable, testable Goji foundation while keeping Supabase/GENOME as the canonical durable state.

**Architecture:** GitHub holds a small Python 3.11 application/integration layer under `goji/`; SportsGameOdds is normalized at the boundary, cold-start decisions use typed domain objects, and all persistent Goji memory flows through existing canonical Supabase RPCs. No local database, duplicate settlement logic, or trained-model claims are introduced.

**Tech Stack:** Python 3.11, `requests`, `pytest`, GitHub Actions, Supabase PostgREST RPC endpoints.

**Spec:** `docs/superpowers/specs/2026-09-15-goji-foundation-design.md`

## Global Constraints

- Supabase/GENOME remains the durable source of truth; do not add SQLite or another persistence layer.
- Preserve the Goji pipeline framing `ECHOSENSE -> CARAPACE -> PLASMA -> SPINES` and provenance needed to reconstruct inputs.
- Keep Goji probability separate from sportsbook/market implied probability.
- Baseline predictions must always be labeled `COLD_START`.
- Return `NO_ROAR` or insufficient-data instead of fabricating confidence.
- Never commit API keys, Supabase credentials, or other secrets.
- Unit tests must pass without live credentials.
- Settlement writes must use the existing canonical GENOME settlement path; this first slice does not introduce a second settlement implementation.
- Python runtime is 3.11 in local docs and CI.
- The target review branch is `Goji-foundation`; `main` stays untouched until review/merge.

---

## File Map

- `goji/__init__.py` — package metadata and stable public imports.
- `goji/config.py` — capability-scoped environment configuration.
- `goji/models.py` — typed normalized event, provenance, and prediction objects.
- `goji/sportsgameodds.py` — SportsGameOdds HTTP client and response normalization.
- `goji/baseline.py` — replaceable cold-start predictor with explicit refusal behavior.
- `goji/genome.py` — thin Supabase RPC adapter; no direct table persistence.
- `scripts/goji_check.py` — small configuration/connectivity smoke check.
- `tests/test_config.py` — config validation tests.
- `tests/test_models.py` — core domain validation/serialization tests.
- `tests/test_sportsgameodds.py` — provider request, normalization, and error tests.
- `tests/test_baseline.py` — cold-start label and insufficient-evidence tests.
- `tests/test_genome.py` — canonical RPC name/payload tests and error context.
- `.github/workflows/ci.yml` — credential-free unit-test CI.
- `.github/workflows/sgo-connectivity.yml` — manual live SportsGameOdds connectivity check using the real `goji` package.
- `requirements.txt` — minimal runtime/test dependencies.
- `README.md` — current Goji identity, capabilities, setup, and limits.

---

### Task 1: Core package, models, and capability-scoped configuration

**Files:**
- Create: `goji/__init__.py`
- Create: `goji/config.py`
- Create: `goji/models.py`
- Create: `tests/test_config.py`
- Create: `tests/test_models.py`
- Create: `requirements.txt`

**Interfaces:**
- Produces: `SportsGameOddsConfig.from_env() -> SportsGameOddsConfig`
- Produces: `GenomeConfig.from_env() -> GenomeConfig`
- Produces: `ConfigError`
- Produces: `Provenance`, `NormalizedEvent`, `PredictionInput`, `PredictionDecision`
- Later tasks import these types; importing `goji` itself must not require any credentials.

- [ ] **Step 1: Write the failing configuration tests**

```python
# tests/test_config.py
import pytest

from goji.config import ConfigError, GenomeConfig, SportsGameOddsConfig


def test_sgo_config_requires_only_sgo_key(monkeypatch):
    monkeypatch.delenv("SPORTSGAMEODDS_API_KEY", raising=False)
    monkeypatch.delenv("SUPABASE_URL", raising=False)
    monkeypatch.delenv("SUPABASE_SERVICE_ROLE_KEY", raising=False)

    with pytest.raises(ConfigError, match="SPORTSGAMEODDS_API_KEY"):
        SportsGameOddsConfig.from_env()


def test_genome_config_does_not_require_sgo_key(monkeypatch):
    monkeypatch.setenv("SUPABASE_URL", "https://example.supabase.co")
    monkeypatch.setenv("SUPABASE_SERVICE_ROLE_KEY", "test-service-key")
    monkeypatch.delenv("SPORTSGAMEODDS_API_KEY", raising=False)

    config = GenomeConfig.from_env()
    assert config.url == "https://example.supabase.co"
    assert config.service_role_key == "test-service-key"
```

- [ ] **Step 2: Write the failing model tests**

```python
# tests/test_models.py
from datetime import datetime, timezone

from goji.models import NormalizedEvent, PredictionDecision, PredictionInput, Provenance


def test_normalized_event_preserves_provider_provenance():
    source_time = datetime(2026, 9, 15, 17, 0, tzinfo=timezone.utc)
    event = NormalizedEvent(
        event_id="evt-1",
        league="MLB",
        home_team="Cardinals",
        away_team="Giants",
        starts_at=source_time,
        provenance=Provenance(provider="SportsGameOdds", source_id="evt-1", observed_at=source_time),
    )
    assert event.provenance.provider == "SportsGameOdds"
    assert event.provenance.source_id == "evt-1"


def test_prediction_decision_keeps_model_probability_separate_from_market_probability():
    decision = PredictionDecision(
        prediction_id="pred-1",
        selection="Cardinals",
        model_probability=0.61,
        market_implied_probability=0.55,
        model_status="COLD_START",
        roar_action="NO_ROAR",
        reason="baseline only",
    )
    assert decision.model_probability == 0.61
    assert decision.market_implied_probability == 0.55
```

- [ ] **Step 3: Run the new tests and verify they fail before implementation**

Run:

```bash
python -m pytest tests/test_config.py tests/test_models.py -v
```

Expected: collection/import failure because `goji.config` and `goji.models` do not exist yet.

- [ ] **Step 4: Implement focused configuration objects**

```python
# goji/config.py
from dataclasses import dataclass
import os


class ConfigError(RuntimeError):
    pass


def _required_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise ConfigError(f"Missing required environment variable: {name}")
    return value


@dataclass(frozen=True)
class SportsGameOddsConfig:
    api_key: str
    base_url: str = "https://api.sportsgameodds.com/v2"
    timeout_seconds: float = 10.0

    @classmethod
    def from_env(cls) -> "SportsGameOddsConfig":
        return cls(api_key=_required_env("SPORTSGAMEODDS_API_KEY"))


@dataclass(frozen=True)
class GenomeConfig:
    url: str
    service_role_key: str
    timeout_seconds: float = 10.0

    @classmethod
    def from_env(cls) -> "GenomeConfig":
        return cls(
            url=_required_env("SUPABASE_URL").rstrip("/"),
            service_role_key=_required_env("SUPABASE_SERVICE_ROLE_KEY"),
        )
```

- [ ] **Step 5: Implement the core dataclasses without provider-specific payload leakage**

```python
# goji/models.py
from dataclasses import dataclass
from datetime import datetime
from typing import Any


@dataclass(frozen=True)
class Provenance:
    provider: str
    source_id: str
    observed_at: datetime


@dataclass(frozen=True)
class NormalizedEvent:
    event_id: str
    league: str
    home_team: str
    away_team: str
    starts_at: datetime
    provenance: Provenance


@dataclass(frozen=True)
class PredictionInput:
    prediction_id: str
    sport: str
    prediction_type: str
    selection: str
    features: dict[str, Any]
    provenance: tuple[Provenance, ...]


@dataclass(frozen=True)
class PredictionDecision:
    prediction_id: str
    selection: str
    model_probability: float | None
    market_implied_probability: float | None
    model_status: str
    roar_action: str
    reason: str
```

- [ ] **Step 6: Add the package initializer and dependencies**

```python
# goji/__init__.py
"""Goji sports prediction foundation."""

__version__ = "0.1.0"
```

```text
# requirements.txt
requests>=2.32,<3
pytest>=8,<9
```

- [ ] **Step 7: Run Task 1 tests**

Run:

```bash
python -m pytest tests/test_config.py tests/test_models.py -v
```

Expected: all Task 1 tests PASS.

- [ ] **Step 8: Commit Task 1**

```bash
git add goji/__init__.py goji/config.py goji/models.py tests/test_config.py tests/test_models.py requirements.txt
git commit -m "feat: establish goji core package"
```

---

### Task 2: SportsGameOdds client and normalization boundary

**Files:**
- Create: `goji/sportsgameodds.py`
- Create: `tests/test_sportsgameodds.py`

**Interfaces:**
- Consumes: `SportsGameOddsConfig`, `NormalizedEvent`, `Provenance`
- Produces: `SportsGameOddsClient.events(league_id: str, odds_available: bool = True, limit: int = 5) -> list[NormalizedEvent]`
- Produces: `SportsGameOddsError`

- [ ] **Step 1: Write failing request/normalization tests**

```python
# tests/test_sportsgameodds.py
from datetime import timezone

import pytest
import requests

from goji.config import SportsGameOddsConfig
from goji.sportsgameodds import SportsGameOddsClient, SportsGameOddsError


class FakeResponse:
    def __init__(self, payload, status_code=200):
        self._payload = payload
        self.status_code = status_code

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"HTTP {self.status_code}")

    def json(self):
        return self._payload


class FakeSession:
    def __init__(self, response=None, error=None):
        self.response = response
        self.error = error
        self.last_request = None

    def get(self, url, *, headers, params, timeout):
        self.last_request = {"url": url, "headers": headers, "params": params, "timeout": timeout}
        if self.error:
            raise self.error
        return self.response


def test_events_authenticates_and_normalizes():
    session = FakeSession(FakeResponse({
        "data": [
            {
                "eventID": "evt-1",
                "leagueID": "MLB",
                "teams": {"home": {"name": "Cardinals"}, "away": {"name": "Giants"}},
                "startsAt": "2026-09-15T23:45:00Z",
            }
        ]
    }))
    client = SportsGameOddsClient(
        SportsGameOddsConfig(api_key="secret", base_url="https://example.test/v2", timeout_seconds=3),
        session=session,
    )

    events = client.events("MLB", odds_available=True, limit=5)

    assert events[0].event_id == "evt-1"
    assert events[0].home_team == "Cardinals"
    assert events[0].starts_at.tzinfo == timezone.utc
    assert session.last_request["headers"]["x-api-key"] == "secret"
    assert session.last_request["params"]["leagueID"] == "MLB"
    assert session.last_request["params"]["limit"] == 5


def test_timeout_is_wrapped_without_secret_leak():
    session = FakeSession(error=requests.Timeout("slow"))
    client = SportsGameOddsClient(SportsGameOddsConfig(api_key="do-not-leak"), session=session)

    with pytest.raises(SportsGameOddsError, match="events request failed") as exc:
        client.events("MLB")

    assert "do-not-leak" not in str(exc.value)
```

- [ ] **Step 2: Run the SportsGameOdds tests and verify failure**

Run:

```bash
python -m pytest tests/test_sportsgameodds.py -v
```

Expected: FAIL because `goji.sportsgameodds` does not exist.

- [ ] **Step 3: Implement minimal HTTP client with explicit normalization**

```python
# goji/sportsgameodds.py
from datetime import datetime, timezone
from typing import Any

import requests

from .config import SportsGameOddsConfig
from .models import NormalizedEvent, Provenance


class SportsGameOddsError(RuntimeError):
    pass


def _parse_time(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


class SportsGameOddsClient:
    def __init__(self, config: SportsGameOddsConfig | None = None, *, session: requests.Session | Any | None = None):
        self.config = config or SportsGameOddsConfig.from_env()
        self.session = session or requests.Session()

    def events(self, league_id: str, odds_available: bool = True, limit: int = 5) -> list[NormalizedEvent]:
        try:
            response = self.session.get(
                f"{self.config.base_url.rstrip('/')}/events/",
                headers={"x-api-key": self.config.api_key},
                params={"leagueID": league_id, "oddsAvailable": str(odds_available).lower(), "limit": limit},
                timeout=self.config.timeout_seconds,
            )
            response.raise_for_status()
            payload = response.json()
        except (requests.RequestException, ValueError) as exc:
            raise SportsGameOddsError(f"SportsGameOdds events request failed: {type(exc).__name__}") from exc

        rows = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(rows, list):
            raise SportsGameOddsError("SportsGameOdds events response missing data list")

        normalized: list[NormalizedEvent] = []
        observed_at = datetime.now(timezone.utc)
        for row in rows:
            try:
                event_id = str(row["eventID"])
                league = str(row.get("leagueID") or league_id)
                teams = row["teams"]
                home_team = str(teams["home"]["name"])
                away_team = str(teams["away"]["name"])
                starts_at = _parse_time(str(row["startsAt"]))
            except (KeyError, TypeError, ValueError) as exc:
                raise SportsGameOddsError("Malformed SportsGameOdds event record") from exc

            normalized.append(
                NormalizedEvent(
                    event_id=event_id,
                    league=league,
                    home_team=home_team,
                    away_team=away_team,
                    starts_at=starts_at,
                    provenance=Provenance(
                        provider="SportsGameOdds",
                        source_id=event_id,
                        observed_at=observed_at,
                    ),
                )
            )
        return normalized
```

- [ ] **Step 4: Run SportsGameOdds tests**

Run:

```bash
python -m pytest tests/test_sportsgameodds.py -v
```

Expected: all Task 2 tests PASS.

- [ ] **Step 5: Run all tests so far**

Run:

```bash
python -m pytest -v
```

Expected: all tests PASS.

- [ ] **Step 6: Commit Task 2**

```bash
git add goji/sportsgameodds.py tests/test_sportsgameodds.py
git commit -m "feat: add SportsGameOdds boundary"
```

---

### Task 3: Explicit cold-start baseline with refusal behavior

**Files:**
- Create: `goji/baseline.py`
- Create: `tests/test_baseline.py`

**Interfaces:**
- Consumes: `PredictionInput`, `PredictionDecision`
- Produces: `ColdStartBaseline.predict(data: PredictionInput) -> PredictionDecision`
- Baseline only emits a numeric model probability when `features["baseline_probability"]` exists and is within `[0, 1]`; otherwise it emits `NO_ROAR` with `model_probability=None`.
- Market implied probability may be copied from `features["market_implied_probability"]` for display/comparison but is never substituted for model probability.

- [ ] **Step 1: Write the failing baseline tests**

```python
# tests/test_baseline.py
from goji.baseline import ColdStartBaseline
from goji.models import PredictionInput


def _input(features):
    return PredictionInput(
        prediction_id="pred-1",
        sport="MLB",
        prediction_type="TEAM",
        selection="Cardinals",
        features=features,
        provenance=(),
    )


def test_baseline_is_always_cold_start_and_no_roar():
    result = ColdStartBaseline().predict(_input({"baseline_probability": 0.63}))
    assert result.model_status == "COLD_START"
    assert result.roar_action == "NO_ROAR"
    assert result.model_probability == 0.63


def test_baseline_refuses_to_copy_market_probability_when_model_evidence_is_missing():
    result = ColdStartBaseline().predict(_input({"market_implied_probability": 0.71}))
    assert result.model_probability is None
    assert result.market_implied_probability == 0.71
    assert result.roar_action == "NO_ROAR"
    assert "insufficient" in result.reason.lower()
```

- [ ] **Step 2: Run baseline tests and verify failure**

Run:

```bash
python -m pytest tests/test_baseline.py -v
```

Expected: FAIL because `goji.baseline` does not exist.

- [ ] **Step 3: Implement the minimal replaceable baseline**

```python
# goji/baseline.py
from .models import PredictionDecision, PredictionInput


class ColdStartBaseline:
    def predict(self, data: PredictionInput) -> PredictionDecision:
        raw_probability = data.features.get("baseline_probability")
        market_probability = data.features.get("market_implied_probability")

        model_probability: float | None = None
        reason = "Insufficient independent pregame evidence for a model probability."
        if isinstance(raw_probability, (int, float)) and 0 <= float(raw_probability) <= 1:
            model_probability = float(raw_probability)
            reason = "Illustrative cold-start baseline from supplied pregame features."

        return PredictionDecision(
            prediction_id=data.prediction_id,
            selection=data.selection,
            model_probability=model_probability,
            market_implied_probability=float(market_probability) if isinstance(market_probability, (int, float)) else None,
            model_status="COLD_START",
            roar_action="NO_ROAR",
            reason=reason,
        )
```

- [ ] **Step 4: Run baseline tests**

Run:

```bash
python -m pytest tests/test_baseline.py -v
```

Expected: all Task 3 tests PASS.

- [ ] **Step 5: Commit Task 3**

```bash
git add goji/baseline.py tests/test_baseline.py
git commit -m "feat: add explicit cold-start baseline"
```

---

### Task 4: Canonical GENOME RPC adapter

**Files:**
- Create: `goji/genome.py`
- Create: `tests/test_genome.py`

**Interfaces:**
- Consumes: `GenomeConfig`
- Produces: `GenomeClient.freeze_slate(slate_id: str, predictions: list[dict], blocked: list[dict] | None = None) -> object`
- Produces: `GenomeClient.review_queue(slate_id: str | None = None) -> object`
- Produces: `GenomeClient.scoreboards(sport: str | None = None) -> object`
- Produces: `GenomeClient.record_wager_link(wager_id: str, prediction_id: str, platform: str, slip_id: str | None = None, stake: float | None = None, metadata: dict | None = None) -> object`
- Produces: `GenomeError`
- Each public method maps only to existing canonical Supabase functions: `genome_freeze_slate`, `genome_review_queue`, `genome_scoreboards`, `genome_record_wager_link`.

- [ ] **Step 1: Write failing RPC mapping and error-context tests**

```python
# tests/test_genome.py
import pytest
import requests

from goji.config import GenomeConfig
from goji.genome import GenomeClient, GenomeError


class FakeResponse:
    def __init__(self, payload, status_code=200):
        self._payload = payload
        self.status_code = status_code
        self.text = "fake response"

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"HTTP {self.status_code}")

    def json(self):
        return self._payload


class FakeSession:
    def __init__(self, response):
        self.response = response
        self.calls = []

    def post(self, url, *, headers, json, timeout):
        self.calls.append({"url": url, "headers": headers, "json": json, "timeout": timeout})
        return self.response


def _client(response):
    return GenomeClient(
        GenomeConfig(url="https://example.supabase.co", service_role_key="service-secret", timeout_seconds=4),
        session=FakeSession(response),
    )


def test_freeze_slate_calls_canonical_rpc():
    client = _client(FakeResponse({"status": "ok"}))
    result = client.freeze_slate("slate-1", [{"prediction_id": "pred-1"}], [])

    call = client.session.calls[0]
    assert call["url"].endswith("/rest/v1/rpc/genome_freeze_slate")
    assert call["json"] == {"p_slate_id": "slate-1", "p_predictions": [{"prediction_id": "pred-1"}], "p_blocked": []}
    assert result == {"status": "ok"}


def test_review_queue_calls_canonical_rpc():
    client = _client(FakeResponse([]))
    client.review_queue("slate-1")
    assert client.session.calls[0]["url"].endswith("/rest/v1/rpc/genome_review_queue")
    assert client.session.calls[0]["json"] == {"p_slate_id": "slate-1"}


def test_rpc_failure_names_operation_without_leaking_secret():
    client = _client(FakeResponse({"message": "nope"}, status_code=500))
    with pytest.raises(GenomeError, match="genome_scoreboards") as exc:
        client.scoreboards("MLB")
    assert "service-secret" not in str(exc.value)
```

- [ ] **Step 2: Run GENOME tests and verify failure**

Run:

```bash
python -m pytest tests/test_genome.py -v
```

Expected: FAIL because `goji.genome` does not exist.

- [ ] **Step 3: Implement a single generic RPC helper plus canonical methods**

```python
# goji/genome.py
from typing import Any

import requests

from .config import GenomeConfig


class GenomeError(RuntimeError):
    pass


class GenomeClient:
    def __init__(self, config: GenomeConfig | None = None, *, session: requests.Session | Any | None = None):
        self.config = config or GenomeConfig.from_env()
        self.session = session or requests.Session()

    def _rpc(self, function_name: str, payload: dict[str, Any]) -> Any:
        try:
            response = self.session.post(
                f"{self.config.url}/rest/v1/rpc/{function_name}",
                headers={
                    "apikey": self.config.service_role_key,
                    "Authorization": f"Bearer {self.config.service_role_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=self.config.timeout_seconds,
            )
            response.raise_for_status()
            return response.json()
        except (requests.RequestException, ValueError) as exc:
            raise GenomeError(f"GENOME RPC {function_name} failed: {type(exc).__name__}") from exc

    def freeze_slate(self, slate_id: str, predictions: list[dict], blocked: list[dict] | None = None) -> Any:
        return self._rpc(
            "genome_freeze_slate",
            {"p_slate_id": slate_id, "p_predictions": predictions, "p_blocked": blocked or []},
        )

    def review_queue(self, slate_id: str | None = None) -> Any:
        return self._rpc("genome_review_queue", {"p_slate_id": slate_id})

    def scoreboards(self, sport: str | None = None) -> Any:
        return self._rpc("genome_scoreboards", {"p_sport": sport})

    def record_wager_link(
        self,
        wager_id: str,
        prediction_id: str,
        platform: str,
        slip_id: str | None = None,
        stake: float | None = None,
        metadata: dict | None = None,
    ) -> Any:
        return self._rpc(
            "genome_record_wager_link",
            {
                "p_wager_id": wager_id,
                "p_prediction_id": prediction_id,
                "p_platform": platform,
                "p_slip_id": slip_id,
                "p_stake": stake,
                "p_metadata": metadata or {},
            },
        )
```

- [ ] **Step 4: Add tests for scoreboard and wager-link payload names**

```python
# append to tests/test_genome.py

def test_scoreboards_payload_matches_canonical_signature():
    client = _client(FakeResponse([]))
    client.scoreboards("MLB")
    assert client.session.calls[0]["json"] == {"p_sport": "MLB"}


def test_wager_link_payload_matches_canonical_signature():
    client = _client(FakeResponse({"status": "ok"}))
    client.record_wager_link(
        wager_id="wager-1",
        prediction_id="pred-1",
        platform="Underdog",
        slip_id="slip-1",
        stake=5.0,
        metadata={"note": "test"},
    )
    assert client.session.calls[0]["url"].endswith("/rest/v1/rpc/genome_record_wager_link")
    assert client.session.calls[0]["json"] == {
        "p_wager_id": "wager-1",
        "p_prediction_id": "pred-1",
        "p_platform": "Underdog",
        "p_slip_id": "slip-1",
        "p_stake": 5.0,
        "p_metadata": {"note": "test"},
    }
```

- [ ] **Step 5: Run GENOME tests and then the full suite**

Run:

```bash
python -m pytest tests/test_genome.py -v
python -m pytest -v
```

Expected: all tests PASS without any live Supabase credentials.

- [ ] **Step 6: Commit Task 4**

```bash
git add goji/genome.py tests/test_genome.py
git commit -m "feat: add canonical genome rpc adapter"
```

---

### Task 5: Smoke check and GitHub Actions

**Files:**
- Create: `scripts/goji_check.py`
- Create: `.github/workflows/ci.yml`
- Modify: `.github/workflows/sgo-connectivity.yml`

**Interfaces:**
- CLI command: `python scripts/goji_check.py --sgo`
- `ci.yml` runs unit tests on Python 3.11 without credentials.
- Manual SportsGameOdds workflow uses `goji.sportsgameodds.SportsGameOddsClient` and the existing `SPORTSGAMEODDS_API_KEY` secret.

- [ ] **Step 1: Add the smoke-check script**

```python
# scripts/goji_check.py
import argparse

from goji.sportsgameodds import SportsGameOddsClient


def main() -> int:
    parser = argparse.ArgumentParser(description="Goji foundation smoke check")
    parser.add_argument("--sgo", action="store_true", help="Query a small SportsGameOdds MLB sample")
    args = parser.parse_args()

    if not args.sgo:
        print("Goji import/configuration smoke check OK")
        return 0

    events = SportsGameOddsClient().events("MLB", odds_available=True, limit=5)
    print(f"SportsGameOdds connection successful. Events received: {len(events)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
```

- [ ] **Step 2: Run the credential-free smoke check locally**

Run:

```bash
python scripts/goji_check.py
```

Expected output:

```text
Goji import/configuration smoke check OK
```

- [ ] **Step 3: Add credential-free CI**

```yaml
# .github/workflows/ci.yml
name: Goji CI

on:
  push:
  pull_request:

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements.txt
      - name: Import smoke check
        run: python scripts/goji_check.py
      - name: Run tests
        run: python -m pytest -v
```

- [ ] **Step 4: Replace the stale Shin import in the manual SportsGameOdds workflow**

Use this complete file:

```yaml
# .github/workflows/sgo-connectivity.yml
name: SportsGameOdds API Connectivity

on:
  workflow_dispatch:

jobs:
  test-sportsgameodds:
    runs-on: ubuntu-latest
    steps:
      - name: Check out Goji
        uses: actions/checkout@v4
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: "3.11"
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements.txt
      - name: Test SportsGameOdds connection
        env:
          SPORTSGAMEODDS_API_KEY: ${{ secrets.SPORTSGAMEODDS_API_KEY }}
        run: python scripts/goji_check.py --sgo
```

- [ ] **Step 5: Run full local verification**

Run:

```bash
python scripts/goji_check.py
python -m pytest -v
```

Expected: smoke check exits 0 and all tests PASS.

- [ ] **Step 6: Commit Task 5**

```bash
git add scripts/goji_check.py .github/workflows/ci.yml .github/workflows/sgo-connectivity.yml
git commit -m "ci: wire goji tests and connectivity checks"
```

---

### Task 6: README and merge-readiness verification

**Files:**
- Modify: `README.md`

**Interfaces:**
- Documentation must identify Goji as the current project, Shin as historical lineage, Supabase/GENOME as canonical durable state, and the current system as a cold-start foundation rather than a trained REACTOR.

- [ ] **Step 1: Replace the README with current Goji documentation**

```markdown
# Goji

Goji is a sports prediction and learning system, evolved from the earlier Shin project. This repository is Goji's runnable Python integration/application layer; Supabase/GENOME remains the canonical durable state for frozen predictions, settlements, experience, and readiness.

## Current foundation

- SportsGameOdds event connectivity and normalization
- explicit provenance at the provider boundary
- cold-start baseline outputs that never impersonate a trained model
- canonical GENOME RPC access for slate freezing, review queues, scoreboards, and wager links
- credential-free unit tests and CI

Goji's first-slice baseline is **COLD_START**. It returns `NO_ROAR` when evidence is insufficient and never substitutes sportsbook implied probability for Goji's own model probability.

## Requirements

- Python 3.11
- `SPORTSGAMEODDS_API_KEY` for the optional live SportsGameOdds check
- `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` for GENOME RPC access

Never commit credentials. Configure them through your local environment or GitHub Actions secrets.

## Setup

```bash
python -m pip install -r requirements.txt
python -m pytest -v
python scripts/goji_check.py
```

Optional live SportsGameOdds smoke check:

```bash
SPORTSGAMEODDS_API_KEY=... python scripts/goji_check.py --sgo
```

## Architecture boundary

GitHub code does not duplicate GENOME. Persistent prediction state and learning state stay in canonical Supabase functions. This repository calls those functions through `goji.genome.GenomeClient`.

## Not implemented in this foundation

A trained REACTOR model, autonomous live-game monitoring, autonomous settlement scheduling, bankroll sizing, a web UI, and every Concept Lab subsystem as Python code are intentionally outside this first slice.
```

- [ ] **Step 2: Run the final credential-free verification suite**

Run:

```bash
python -m compileall -q goji scripts
python scripts/goji_check.py
python -m pytest -v
```

Expected: compile exits 0, smoke check exits 0, and all tests PASS.

- [ ] **Step 3: Verify no secret values are committed**

Run:

```bash
git grep -n -E 'ghp_[A-Za-z0-9]+|SPORTSGAMEODDS_API_KEY=[^.]|SUPABASE_SERVICE_ROLE_KEY=[^.]' -- . ':!docs/superpowers' || true
```

Expected: no credential values; only environment-variable names may appear in source/workflows/docs.

- [ ] **Step 4: Verify branch-only diff against main**

Run:

```bash
git status --short
git diff --check main...HEAD
git diff --stat main...HEAD
```

Expected: clean worktree, no whitespace errors, and changes limited to the files named in this plan.

- [ ] **Step 5: Commit Task 6**

```bash
git add README.md
git commit -m "docs: document goji foundation"
```

- [ ] **Step 6: Final review checkpoint before PR**

Run:

```bash
python -m pytest -v
git log --oneline main..HEAD
```

Expected: all tests PASS and the branch contains the six focused foundation commits from this plan. Open a pull request from `Goji-foundation` into `main` only after this checkpoint passes.

---

## Self-Review

- Spec coverage: all approved first-slice components are mapped to tasks: config, typed models, SportsGameOdds, cold-start baseline, canonical GENOME access, smoke CLI, CI, connectivity workflow, tests, and README.
- Out-of-scope items remain out of implementation: trained REACTOR, autonomous monitoring/settlement scheduling, bankroll sizing, web UI, full Concept Lab code, historical migration, and repo rename.
- No placeholders remain in the implementation steps.
- Interface names are consistent across tasks: `SportsGameOddsClient`, `GenomeClient`, `ColdStartBaseline`, and the four canonical GENOME RPC names.
