"""Goji sports prediction foundation."""

__version__ = "0.1.0"
